/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progtakehometest;

/**
 *
 * @author jaido
 */
public class ProgTakeHomeTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // prices for Mirrorless and DSLR cameras
        String[] manufacturers = {"CANON", "SONY", "NIKON"};
        double[][] cameraPrices = {
            {10500.00, 8500.00},
            {9500.00, 7200.00},
            {12000.00, 8000.00} 
        };

        // price difference and its manufacturer
        double maxPriceDifference = 0;
        String manufacturerWithMaxDifference = "";

        // header for the camera technology report
        System.out.println("----------------------------------------------------");
        System.out.println("CAMERA TECHNOLOGY REPORT");
        System.out.println("----------------------------------------------------");
        System.out.println("\tMIRRORLESS\tDSLR\t\tCOST DIFFERENCE");

        // price difference for each manufacturer
        for (int i = 0; i < manufacturers.length; i++) {
            String manufacturer = manufacturers[i];
            double mirrorlessPrice = cameraPrices[i][0];
            double dslrPrice = cameraPrices[i][1];
            double priceDifference = mirrorlessPrice - dslrPrice;

            // Check if the price difference is greater than or equal to R2,500
            String stars = (priceDifference >= 2500) ? "***" : "";

            // manufacturer, prices, and price difference
            System.out.println(manufacturer + "\tR " + mirrorlessPrice + "\tR " + dslrPrice + "\t" + priceDifference + " " + stars);

            // maximum price difference and its manufacturer
            if (priceDifference > maxPriceDifference) {
                maxPriceDifference = priceDifference;
                manufacturerWithMaxDifference = manufacturer;
            }
        }
        
        // manufacturer with the greatest cost difference
        System.out.println("\nCAMERA WITH THE MOST COST DIFFERENCE: " + manufacturerWithMaxDifference);
        System.out.println("----------------------------------------------------");
        
    }

}
        



