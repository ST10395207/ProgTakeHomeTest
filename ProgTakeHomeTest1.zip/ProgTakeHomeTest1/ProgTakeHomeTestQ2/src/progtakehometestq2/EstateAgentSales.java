/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progtakehometestq2;

/**
 *
 * @author jaido
 */
public class EstateAgentSales extends EstateAgent {
    
    public EstateAgentSales(String agentName, double propertySaleAmount) {
        super(agentName, propertySaleAmount);
    }

    // Method to print the estate agent report
    public void printPropertyReport() {
        
        System.out.println("\nESTATE AGENT REPORT");
        System.out.println("********************");
        System.out.println("ESTATE AGENT NAME: " + getAgentName());
        System.out.println("PROPERTY PRICE: R " + getPropertyPrice());
        System.out.println("AGENT COMMISSON: R " + getAgentCommission());
    }

} 


