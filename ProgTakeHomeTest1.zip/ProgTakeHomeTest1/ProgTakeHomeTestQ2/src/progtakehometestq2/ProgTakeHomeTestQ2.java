/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progtakehometestq2;

import java.util.Scanner;

/**
 *
 * @author jaido
 */
public class ProgTakeHomeTestQ2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
        Scanner kb = new Scanner(System.in);

        // agent's name
        System.out.print("Enter the current estate agent name: ");
        String agentName = kb.nextLine();

        // property price
        System.out.print("Enter the property price: R ");
        double propertyPrice = kb.nextDouble();
        
        // estateAgentSales with values
        EstateAgentSales agent = new EstateAgentSales(agentName, propertyPrice);

        // property report
        agent.printPropertyReport();
        
    }

} 
    

