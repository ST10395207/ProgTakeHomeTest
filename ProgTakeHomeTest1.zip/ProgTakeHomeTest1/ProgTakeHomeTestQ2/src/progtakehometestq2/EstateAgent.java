/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progtakehometestq2;

/**
 *
 * @author jaido
 */
public abstract class EstateAgent implements iEstateAgent {
    
    private final String agentName;
    private final double propertyPrice;

    public EstateAgent(String agentName, double propertyPrice) {
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
    }

    @Override
    public String getAgentName() {
        return agentName;
    }

    @Override
    public double getPropertyPrice() {
        return propertyPrice;
    }

    // 20% of the property price
    @Override
    public double getAgentCommission() {
        return propertyPrice * 0.20; 
    }
}



